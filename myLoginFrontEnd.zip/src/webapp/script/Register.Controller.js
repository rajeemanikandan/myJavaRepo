 app.controller("RegisterController", function($scope, $http) {

                $scope.users = [];

                $scope.registerUSer = function() {

                    var method = "POST";
                    var  url = 'http://localhost:8081/myLogin/api/signUp';

                    $http({
                        method : method,
                        url : url,
                        data : angular.toJson($scope.user),
                        headers : {
                            'Content-Type' : 'application/json'
                        }
                    }).then( _success, _error );
                };

                function _success(response) {
                     $mdDialog.show({

                          templateUrl: 'dialog1.tmpl.html',
                          parent: angular.element(document.body),
                          targetEvent: ev,
                          clickOutsideToClose:true,
                          fullscreen: $scope.customFullscreen
                        })
                }

                function _error(response) {
                    alert(response.errorMessage);
                }


  });