 app.controller("LoginController", function($scope, $http) {

                $scope.users = [];

                $scope.login = function() {

                    var method = "POST";
                    var  url = 'http://localhost:8081/myLogin/api/login';

                    $http({
                        method : method,
                        url : url,
                        data : angular.toJson($scope.user),
                        headers : {
                            'Content-Type' : 'application/json'
                        }
                    }).then( _success, _error );
                };

                function _success(response) {
                   $state.go("home");
                }

                function _error(response) {
                    alert(response.errorMessage);
                }


  });