package com.mylogin.controller;

import org.junit.Test;

public class LoginControllerTest {
    @Test
    public void findAllUsers() throws Exception {

    }
}
