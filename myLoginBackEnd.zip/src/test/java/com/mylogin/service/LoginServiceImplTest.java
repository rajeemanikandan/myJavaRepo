package com.mylogin.service;

import com.mylogin.model.User;
import org.junit.Before;
import org.junit.Test;


import java.util.Date;

import static org.junit.Assert.*;

public class LoginServiceImplTest {


    LoginService service;

   @Before
   public void setup(){
       service = new LoginServiceImpl();
   }

    @Test
    public void testIsValidEmail() throws Exception {
        boolean result= service.isValidEmail("rajee@gmail.com");
        boolean result1= service.isValidEmail("rajeegmail.com");
        assertTrue("This will succeed.", result);
        assertFalse("This will fail.", result1);

    }

    @Test
    public void testValidateUser() throws Exception {
        User user = new User();
        user.setFirstName("Raj");
        user.setDateOfBirth(new Date());
        user.setEmail("fafa");
        user.setLastName("MAni");
        user.setPassword("Mypsd");
        boolean result = service.validateUser(user);
        user.setPhoneNumber(123L);
        boolean result1 = service.validateUser(user);
        assertTrue("This will succeed.", result1);
        assertFalse("This will fail.", result);

    }

    @Test
    public void testValidateLoginData() throws Exception {
        User user = new User();
        user.setEmail("fafa");
        boolean result = service.validateLoginData(user);
        user.setPassword("Mypsd");
        boolean result1 = service.validateLoginData(user);
        assertTrue("This will succeed.", result1);
        assertFalse("This will fail.", result);

    }

    @Test
    public void testSaveUser() throws Exception {
        User user = new User();
        user.setFirstName("Raj");
        user.setDateOfBirth(new Date());
        user.setEmail("fafa");
        user.setLastName("MAni");
        user.setPassword("Mypsd");
        user.setPhoneNumber(123L);
        service.saveUser(user);

    }

    @Test
    public void testIsUserExist() throws Exception {
        User user = new User();
        user.setFirstName("Raj");
        user.setDateOfBirth(new Date());
        user.setEmail("rajeepon@gmai.com");
        user.setLastName("MAni");
        user.setPassword("Mypsd");
        user.setPhoneNumber(123L);
        boolean result =  service.isUserExist(user);
        user.setEmail("rajeepon@gmaicom");
        boolean result1 = service.isUserExist(user);
        assertTrue("This will succeed.", result);
        assertFalse("This will fail.", result1);
    }


    @Test
    public void testFindUser() throws Exception {
        User user = new User();
        user.setFirstName("Raj");
        user.setDateOfBirth(new Date());
        user.setEmail("rajeepon@gmai.com");
        user.setLastName("MAni");
        user.setPassword("password123");
        user.setPhoneNumber(123L);
        User result =  service.findUser(user);
        user.setEmail("rajeepon@gmaicom");
        User result1 = service.findUser(user);
        assertNotNull("This will succeed.", result);
        assertNull("This will fail.", result1);
    }


}
