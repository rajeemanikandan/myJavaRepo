package com.mylogin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication(scanBasePackages={"com.mylogin"})
public class MyLoginApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyLoginApplication.class, args);
	}
}
