package com.mylogin.service;


import java.util.List;

import com.mylogin.model.User;

public interface LoginService {

    boolean validateLoginData(User user);

    boolean isValidEmail(String email);

    boolean isUserExist(User user);

    boolean validateUser(User user);

    List<User> findAllUsers();

    void saveUser(User user);

    User findUser(User user);

}
