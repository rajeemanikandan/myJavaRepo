package com.mylogin.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

import org.springframework.stereotype.Service;

import com.mylogin.model.User;



@Service("userService")
public class LoginServiceImpl implements LoginService {
	
	private static final AtomicLong counter = new AtomicLong();
	
	private static List<User> users;
	
	static{
		makeDummyData();
	}

	public List<User> findAllUsers() {
		return users;
	}
	
	public boolean isValidEmail(String email) {
		String regex = "^[\\w-_\\.+]*[\\w-_\\.]\\@([\\w]+\\.)+[\\w]+[\\w]$";
		return email.matches(regex);
	}

	public boolean validateUser(User user) {
		return (null != user.getFirstName() && null!=user.getLastName() &&
		null !=user.getEmail() && null!=user.getDateOfBirth() &&
		null != user.getPassword() && null!=user.getPhoneNumber());

	}

	public boolean validateLoginData(User user){
		return (null !=user.getEmail()  &&
				null != user.getPassword());
	}

	private User findByUserName(String email) {
		return users.stream().filter(user->email.equalsIgnoreCase(user.getEmail())).findAny().orElse(null);
	}
	
	public void saveUser(User user) {
		user.setId(counter.incrementAndGet());
		users.add(user);
	}

	public boolean isUserExist(User user) {
		return findByUserName(user.getEmail())!=null;
	}

	public User findUser(User loginUser) {
		return users.stream().filter(user -> (
				loginUser.getEmail().equalsIgnoreCase(user.getEmail()) && loginUser.getPassword().equalsIgnoreCase(user.getPassword()))).findAny().orElse(null);
	}

	private static void makeDummyData(){
		List<User> userList = new ArrayList<User>();
		LocalDate localDate = LocalDate.now();
		userList.add(new User(counter.incrementAndGet(),"Rajeswari","Manikandan","rajeepon@gmai.com","password123",9785285212L, new Date()));
		users = userList;
	}

}
